const bdark = document.querySelector('#bdark');
const body = document.querySelector('body');
bdark.addEventListener('click', e =>{body.classList.toggle('darkmode');});